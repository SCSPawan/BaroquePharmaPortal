    <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> &copy; Baroque Pharmaceuticals Pvt. Ltd.
                            </div>
                            <div class="col-sm-6">
                               <!--  <div class="text-sm-end d-none d-sm-block">
                                    Developed By <i class="mdi mdi-heart text-danger"></i> <a href="" target="_blank" class="text-reset">Softcore Solution Pvt. Ltd</a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

       

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- JAVASCRIPT -->
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/metismenujs/metismenujs.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/feather-icons/feather.min.js"></script>

        <!-- apexcharts -->
        <!-- <script src="assets/libs/apexcharts/apexcharts.min.js"></script> -->
        <!-- Chart JS -->
        <!-- <script src="assets/js/pages/chartjs.js"></script> -->

        <script src="assets/js/pages/dashboard.init.js"></script>

        <script src="assets/js/app.js"></script>
    </body>

</html>
