 <style type="text/css">
.mt-6{margin-top: -6px !important;}
.FreightInput {width: 100px;border: transparent;}
.FreightInput:focus {border: transparent;outline: none;}
 </style>
 <!--start qc check model-->

        <div class="modal fade fg-qc-check" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="myLargeModalLabel">QC Check </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="page-content">
                            <div class="container-fluid">
                                  <div class="card">
                                <div class="card-body">
                                 <div class="row">
                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">PO No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">GR NO</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Item Code</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Item Name</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Generic Name</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Whs</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">In House Id
                                                </label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Valid Up To</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Test Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Batch No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Batch Size</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Pack Size</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Mfg.Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Exp.Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">A/R.No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Received Qty</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Sample Qty</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Sam.Incube Dt.</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">QC Check No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Mode/Type</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Posting Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Analysis Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Stage</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Plant/Location</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Manufacture</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">No. Container</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Sample Type</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">QC Test Type</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="d-flex flex-wrap gap-2">
                                            <!-- Toggle States Button -->
                                            <!-- <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Container Selection</button> -->
                                        </div>
                                       </div>
                                    </div>
                                </div>
                                    <br><br>    
                             <div class="row">
                            <div class="col-xl-12">
                                <div class="card">                                
                                    <div class="card-body">
                                        
                                                <div class="table-responsive qc_list_table table_item_padding" id="list">
                                                    <table id="tblItemRecord" class="table sample-table-responsive table-bordered" style="">
                                                        <thead class="fixedHeader1">
                                                            <tr>
                                                                <th>Parametre Code</th>
                                                                <th>Parametre Name </th>  
                                                                <th>Result Type</th>
                                                                <th>Test Method</th>
                                                                <th>Material Type</th> 
                                                                <th>UOM</th> 
                                                                <th>Descriptive Details</th> 
                                                                <th>Lower Min</th> 
                                                                <th>Lower Max</th> 
                                                                <th>Upper Min</th> 
                                                                <th>Upper Max</th> 
                                                                <th>Observation</th> 
                                                                <th>Result</th> 
                                                                <th>Analysis By</th> 
                                                                <th>Instrument Code</th> 
                                                                <th>Instrument Name</th> 
                                                                <th>From Time</th> 
                                                                <th>To Time</th> 
                                                               <!--  <th>Attachment Excel</th>  -->
                                                            </tr>
                                                        </thead>
                                                     <tbody>
                                                        <tr>
                                                            <td class="desabled">1</td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td><input  type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                             <td ><input type="text" id="" name="" class="form-control"></td>
                                                         </tr>

                                                         <tr>
                                                            <td class="desabled">1</td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td><input  type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                          
                                                         </tr>

                                                         <tr>
                                                            <td class="desabled">1</td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td><input  type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                          
                                                         </tr>

                                                         <tr>
                                                            <td class="desabled">1</td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td><input  type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                           
                                                         </tr>

                                                         <tr>
                                                            <td class="desabled">1</td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td class="desabled"></td>
                                                            <td><input  type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                            <td ><input type="text" id="" name="" class="form-control"></td>
                                                           
                                                         </tr>

                                                       </tbody> 

                                                   </table>
                                               </div> 
                                            <!--end table-->
                                            <div class="bottom-col">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <table id="example" class="table table-bordered nowrap display w-100 dataTable" style="height: 140px;">
                                                        <tfoot class="">
                                                            <tr>
                                                                
                                                                <th colspan="2">Assay Potency %</th>
                                                                <td colspan="2">
                                                                    <input type="text" value="99.3" class="FreightInput">
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                               
                                                                <th class="replaceId" colspan="2"  id="myBtn">LOD/Water</th>
                                                                <td colspan="2">
                                                                    <input type="text" value="2608" class="FreightInput">
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                               
                                                                <th colspan="2">Compiled By</th>
                                                                <td colspan="2">
                                                                    <input type="text" name="TaxAmount" id="TaxAmount" value="00.00" class="FreightInput" readonly="">
                                                                </td>
                                                            </tr>
                                            
                                                            <tr>
                                                              
                                                                <th colspan="2">Checked  By</th>
                                                                <td colspan="2">
                                                                    <input type="text" name="Rounding" id="Rounding" value="00.00" class="FreightInput" readonly="">
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                               
                                                                <th colspan="2">Remark</th>
                                                                <td colspan="2">
                                                                    <div class="form-group green-border-focus">
                                                                    <textarea placeholder="Remark1" style=" resize: none;" class="form-control" id="Remark1" name="Remark1" rows="3"></textarea>
                                                                </div>
                                                                </td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                    </div><!--col-md-4 closed-->
                                                    <div class="col-md-4">

                                                       <table id="tblItemRecord" class="table sample-table-responsive table_inline table-bordered" style="">
                                                        <thead class="fixedHeader1">
                                                            <tr>
                                                                 <th colspan="2">QC Check</th>
                                                                 <th>Quantity</th>
                                                            </tr>
                                                        </thead>
                                                     <tbody>
                                                           
                                                            <tr>
                                                                <td>Status</td>
                                                            <td>
                                                                <select class="form-select samp-selct">
                                                                    <option>Select</option>
                                                                    <option>Accepted</option>
                                                                    <option>Rejected</option>
                                                                    <option>OOS</option>
                                                                    <option>Re-sample</option>
                                                                    <option>Incident</option>
                                                                </select>
                                                            </td>
                                                            <td>50</td>
                                                            </tr>

                                                             <tr>
                                                                <td>Status</td>
                                                            <td>
                                                                <select class="form-select samp-selct">
                                                                    <option>Select</option>
                                                                    <option>Accepted</option>
                                                                    <option>Rejected</option>
                                                                    <option>OOS</option>
                                                                    <option>Re-sample</option>
                                                                    <option>Incident</option>
                                                                </select>
                                                            </td>
                                                            <td>50</td>
                                                            </tr>

                                                             <tr>
                                                                <td>Status</td>
                                                            <td>
                                                                <select class="form-select samp-selct">
                                                                   <option>Select</option>
                                                                    <option>Accepted</option>
                                                                    <option>Rejected</option>
                                                                    <option>OOS</option>
                                                                    <option>Re-sample</option>
                                                                    <option>Incident</option>
                                                                </select>
                                                            </td>
                                                            <td>50</td>
                                                            </tr>
                                                        </tbody>
                                                        </table>

                                                    </div><!--col-md-4-->
                                                    <div class="col-md-4">
                                                    <table id="tblItemRecord" class="table sample-table-responsive table_inline table-bordered" style="">
                                                        <thead class="fixedHeader1">
                                                            <tr>
                                                                 <th colspan="2">Remark</th>
                                                            </tr>
                                                        </thead>
                                                     <tbody>
                                                        <tr>
                                                            <td>Rejection Remark</td>
                                                            <td> <input type="text" value="" class="form-control"></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Onhold Remark</td>
                                                            <td><input type="text" value="" class="form-control"></td>
                                                        </tr>
                                                        <tr>
                                                            <td>OOS Remark</td>
                                                            <td><input type="text" value="" class="form-control"></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Incident Remark</td>
                                                            <td><input type="text" value="" class="form-control"></td>
                                                        </tr>
                                                    </tbody>
                                                    </table>
                                                    </div><!--col-md-4-->
                                                </div>
                                            </div>
                                            
                                                        <!-- -------footer button---- -->
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="d-flex flex-wrap gap-2">
                                                                    <!-- Toggle States Button -->
                                                                    <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Add</button>

                                                                     <button type="button" class="btn btn-primary active" data-bs-toggle="button" autocomplete="off">Cancel</button>

                                                                     <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Inventory Transfer</button>
                                                                     
                                                                    <div class="form-group row mb-2">
                                                                    <label class="col-lg-4 col-form-label mt-6" for="val-skill">IT No</label>
                                                                    <div class="col-lg-8">
                                                                        <input class="form-control" type="text" id="" name="">
                                                                    </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                                <div class="col-md-6" >
                                                                    <div class="d-flex flex-wrap gap-2 float-right qc_footer_right">
                                                                    <div class="qc_attatchment">
                                                                      <input class="form-control" type="file" id="formFile">
                                                                    </div>

                                                                     <button type="button" class="btn btn-primary active" data-bs-toggle="button" autocomplete="off">Print</button>

                                                                     <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">
                                                                     QC Analysis Print</button>
                                                                 </div>
                                                                </div>
                                                            </div>

                                                        <!-- ------footer button end---- -->
                                            
                                        </div>
                                    </div><!-- end card-body -->
                                </div><!-- end card -->
                            </div><!-- end col -->

                                                        
                        </form>
                        </div><!--container-fluid-->
                    </div><!--page-content-->
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    </div>

     <!--end qc check model-->

     <style type="text/css">
    .modal-body{padding: 0 !important;
     </style>
    }

   <script type="text/javascript">
(function ($) {

  $.fn.enableCellNavigation = function () {

    var arrow = {
      left: 37,
      up: 38,
      right: 39,
      down: 40
    };

    // select all on focus
    // works for input elements, and will put focus into
    // adjacent input or textarea. once in a textarea,
    // however, it will not attempt to break out because
    // that just seems too messy imho.
    this.find('input').keydown(function (e) {

      // shortcut for key other than arrow keys
      if ($.inArray(e.which, [arrow.left, arrow.up, arrow.right, arrow.down]) < 0) {
        return;
      }

      var input = e.target;
      var td = $(e.target).closest('td');
      var moveTo = null;

      switch (e.which) {

        case arrow.left:
          {
            if (input.selectionStart == 0) {
              moveTo = td.prev('td:has(input,textarea)');
            }
            break;
          }
        case arrow.right:
          {
            if (input.selectionEnd == input.value.length) {
              moveTo = td.next('td:has(input,textarea)');
            }
            break;
          }

        case arrow.up:
        case arrow.down:
          {

            var tr = td.closest('tr');
            var pos = td[0].cellIndex;

            var moveToRow = null;
            if (e.which == arrow.down) {
              moveToRow = tr.next('tr');
            } else if (e.which == arrow.up) {
              moveToRow = tr.prev('tr');
            }

            if (moveToRow.length) {
              moveTo = $(moveToRow[0].cells[pos]);
            }

            break;
          }

      }

      if (moveTo && moveTo.length) {

        e.preventDefault();

        moveTo.find('input,textarea').each(function (i, input) {
          input.focus();
          input.select();
        });

      }

    });

  };

})(jQuery);


// use the plugin
$(function () {
  $('#list').enableCellNavigation();
});


</script>
