 <style type="text/css">
.mt-6{margin-top: -6px !important;}
 </style>

    <!--start sample collection Finished Goods model-->

        <div class="modal fade sample-collection-in-process" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="myLargeModalLabel">Sample Collection - In Process </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row">

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Ingediant Type</label>
                                                <div class="col-lg-8">
                                                    <select class="form-select">
                                                        <option>None</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Receipt No</label>
                                                <div class="col-lg-4">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                                 <div class="col-lg-4">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">WO No</label>
                                                <div class="col-lg-4">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                                 <div class="col-lg-4">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Doc No</label>
                                                <div class="col-lg-4">
                                                    <select class="form-control">
                                                        <option></option>
                                                    </select>
                                                </div>
                                                 <div class="col-lg-4">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Location</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Intimated By</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Intimated Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Sample Qty </label>
                                                <div class="col-lg-6">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                                <div class="col-lg-2">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-5 col-form-label mt-6" for="val-skill">Sample Collect By</label>
                                                <div class="col-lg-7">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">A/R No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-6 col-form-label mt-6" for="val-skill">Sample Recieved Sepretly</label>
                                                <div class="col-lg-6">
                                                    <select class="form-select">
                                                        <option>Select</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">DocDate</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">TR No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Branch</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Item Code</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Item Name</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Batch No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">No.Of Container</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                       <!--  <div class="d-flex flex-wrap gap-2">
                                          
                                            <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Container Selection</button>
                                        </div> -->
                                       
                                    </div>

                                    <br><br>    
                             <div class="row">
                            <div class="col-xl-12">
                                <div class="card">                                
                                    <div class="card-body">
                                        <!-- Nav tabs -->
                                        <ul class="nav nav-tabs" role="tablist">

                                            <li class="nav-item">
                                                <a class="nav-link active" data-bs-toggle="tab" href="#samp_details" role="tab">
                                                    <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                                                    <span class="d-none d-sm-block">Sample Collection Details</span>    
                                                </a>
                                            <li class="nav-item">
                                                <a class="nav-link" data-bs-toggle="tab" href="#home" role="tab">
                                                    <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                                                    <span class="d-none d-sm-block">External</span>    
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-bs-toggle="tab" href="#profile" role="tab">
                                                    <span class="d-block d-sm-none"><i class="far fa-user"></i></span>
                                                    <span class="d-none d-sm-block">Extra Issue</span>    
                                                </a>
                                            </li>
                                        </ul>
        
                                        <!-- Tab panes -->

                                        <div class="tab-content p-3 text-muted">
                                            <div class="tab-pane active" id="samp_details" role="tabpanel">
                                                <!-- form start -->
                                                <form>
                                                     <div class="row">

                                                        <div class="col-xl-3 col-md-6">
                                                            <div class="form-group row mb-2">
                                                                <label class="col-lg-6 col-form-label mt-6" for="val-skill">UnderTest Transfer No</label>
                                                                <div class="col-lg-6">
                                                                    <input type="text" name="" class="form-control desabled">
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-xl-3 col-md-6">
                                                            <div class="form-group row mb-2">
                                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Date of Reversal</label>
                                                                <div class="col-lg-8">
                                                                    <input type="text" name="" class="form-control">
                                                                </div>
                                                            </div>
                                                        </div>

                                                     </div>

                                                     <div class="row">

                                                        <div class="col-xl-3 col-md-6">
                                                            <div class="form-group row mb-2">
                                                                <div class="col-md-5">
                                                                    <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Sample Issue</button>
                                                                </div>
                                                                <div class="col-lg-7 container_input">
                                                                    <input type="text" name="" class="form-control desabled">
                                                                 </div>
                                                            </div>
                                                        </div>

                                                         <div class="col-xl-4 col-md-6">
                                                            <div class="form-group row mb-2">
                                                                <div class="col-md-5">
                                                                    <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Reverse Sample Issue</button>
                                                                </div>
                                                                <div class="col-lg-6 container_input">
                                                                    <input type="text" name="" class="form-control desabled">
                                                                 </div>
                                                            </div>
                                                        </div>

                                                     </div>

                                                     <div class="row">

                                                        <div class="col-xl-3 col-md-6">
                                                            <div class="form-group row mb-2">
                                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Container No</label>
                                                                <div class="col-lg-8 container_input" style="display: inline-flex;">
                                                                    <input type="text" name="" class="form-control desabled">
                                                                    <input type="text" name="" class="form-control">
                                                                    <input type="text" name="" class="form-control">
                                                                 </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-xl-3 col-md-6">
                                                            <div class="form-group row mb-2">
                                                                <label class="col-lg-4 col-form-label mt-6" for="val-skill">Qty For Label</label>
                                                                <div class="col-lg-8">
                                                                    <input type="text" name="" class="form-control">
                                                                </div>
                                                            </div>
                                                        </div>

                                                     </div>
                                                </form>        
                                                <!-- form end -->
                                                <div class="d-flex flex-wrap gap-2">
                                                    <!-- Toggle States Button -->
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Sample Print</button>

                                                </div>
                                            </div>

                                            <div class="tab-pane" id="home" role="tabpanel">
                                                    <div class="table-responsive" id="list">
                                                    <table id="tblItemRecord" class="table sample-table-responsive table-bordered" style="">
                                                            <thead class="fixedHeader1">
                                                                <tr>
                                                                    <th>Sr. No</th>
                                                                    <th>Supplier Code</th>
                                                                    <th>Supplier Name</th>
                                                                    <th>UOM </th>  
                                                                    <th>Sample Date</th>
                                                                    <th>Warehouse</th>
                                                                    <th>Sample Quantity</th>
                                                                    <th>Inventory Transfer</th> 
                                                                </tr>
                                                            </thead>
                                                         <tbody>
                                                            <tr>
                                                                <td></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td class="desabled"><input class="border_hide desabled" type="text" id="" name="" class="form-control"></td>
                                                                <td></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td class="desabled"><input class="border_hide desabled" type="text" id="" name="" class="form-control"></td>
                                                             </tr>

                                                             <tr>
                                                                <td></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td class="desabled"><input class="border_hide desabled" type="text" id="" name="" class="form-control"></td>
                                                                <td></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td class="desabled"><input class="border_hide desabled" type="text" id="" name="" class="form-control"></td>
                                                             </tr>

                                                             <tr>
                                                                <td></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td class="desabled"><input class="border_hide desabled" type="text" id="" name="" class="form-control"></td>
                                                                <td></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td class="desabled"><input class="border_hide desabled" type="text" id="" name="" class="form-control"></td>
                                                             </tr>
                                                           </tbody> 

                                                       </table>
                                                   </div> 
                                                   <div class="d-flex flex-wrap gap-2">
                                                        <!-- Toggle States Button -->
                                                        <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Transfer</button>

                                                         <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Issue Sleep</button>
                                                    </div>
                                            </div>
                                            <div class="tab-pane" id="profile" role="tabpanel">
                                                <div class="table-responsive" id="list">
                                                    <table id="tblItemRecord" class="table sample-table-responsive table-bordered" style="">
                                                          <thead class="fixedHeader1">
                                                                <tr>
                                                                    <th>Sr. No</th>
                                                                    <th>Sample Quantity</th>
                                                                    <th>UOM</th>
                                                                    <th>Warehouse</th>
                                                                    <th>Sample By</th>  
                                                                    <th>Issue Date</th>
                                                                    <th>Post Extra Issue</th>
                                                                </tr>
                                                            </thead>
                                                         <tbody>
                                                            <tr>
                                                                <td></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td class="desabled"><input class="border_hide desabled" type="text" id="" name="" class="form-control"></td>
                                                             </tr>

                                                             <tr>
                                                                <td></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td class="desabled"><input class="border_hide desabled" type="text" id="" name="" class="form-control"></td>
                                                             </tr>

                                                             <tr>
                                                                <td></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td><input class="border_hide" type="text" id="" name="" class="form-control"></td>
                                                                <td class="desabled"><input class="border_hide desabled" type="text" id="" name="" class="form-control"></td>
                                                             </tr>
                                                           </tbody> 

                                                       </table>
                                               </div> 
                                                <div class="d-flex flex-wrap gap-2">
                                                            <!-- Toggle States Button -->
                                                            <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Post Extra Issue</button>

                                                             <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Issue Slip</button>

                                                        </div>
                                            </div>
                                            
                                        </div>
                                    </div><!-- end card-body -->
                                </div><!-- end card -->
                            </div><!-- end col -->

                          <div class="d-flex flex-wrap gap-2 mt-2">
                              <!-- Toggle States Button -->
                              <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Add</button>

                               <button type="button" class="btn btn-primary active" data-bs-toggle="button" autocomplete="off">Cancel</button>

                          </div>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    </div>

     <!--end sample collection model-->


        <script type="text/javascript">
(function ($) {

  $.fn.enableCellNavigation = function () {

    var arrow = {
      left: 37,
      up: 38,
      right: 39,
      down: 40
    };

    // select all on focus
    // works for input elements, and will put focus into
    // adjacent input or textarea. once in a textarea,
    // however, it will not attempt to break out because
    // that just seems too messy imho.
    this.find('input').keydown(function (e) {

      // shortcut for key other than arrow keys
      if ($.inArray(e.which, [arrow.left, arrow.up, arrow.right, arrow.down]) < 0) {
        return;
      }

      var input = e.target;
      var td = $(e.target).closest('td');
      var moveTo = null;

      switch (e.which) {

        case arrow.left:
          {
            if (input.selectionStart == 0) {
              moveTo = td.prev('td:has(input,textarea)');
            }
            break;
          }
        case arrow.right:
          {
            if (input.selectionEnd == input.value.length) {
              moveTo = td.next('td:has(input,textarea)');
            }
            break;
          }

        case arrow.up:
        case arrow.down:
          {

            var tr = td.closest('tr');
            var pos = td[0].cellIndex;

            var moveToRow = null;
            if (e.which == arrow.down) {
              moveToRow = tr.next('tr');
            } else if (e.which == arrow.up) {
              moveToRow = tr.prev('tr');
            }

            if (moveToRow.length) {
              moveTo = $(moveToRow[0].cells[pos]);
            }

            break;
          }

      }

      if (moveTo && moveTo.length) {

        e.preventDefault();

        moveTo.find('input,textarea').each(function (i, input) {
          input.focus();
          input.select();
        });

      }

    });

  };

})(jQuery);


// use the plugin
$(function () {
  $('#list').enableCellNavigation();
});


</script>
