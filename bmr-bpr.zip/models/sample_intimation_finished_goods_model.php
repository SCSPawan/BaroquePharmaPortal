 <style type="text/css">
.mt-6{margin-top: -6px !important;}
 </style>
<!--sample intimation model-->
    <div class="modal fade sample-intimation-finished-goods" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="myLargeModalLabel">Sample Intimation - Finished Goods</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- form start -->

                                <form>
                                     <div class="row">

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Receipt No</label>
                                                 <div class="col-lg-6">
                                                    <input class="form-control desabled" type="text" id="" name="" readonly>
                                                </div>
                                                 <div class="col-lg-2">
                                                    <input class="form-control desabled" type="text" id="" name="" readonly>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Doc No</label>
                                                <div class="col-lg-6">
                                                    <select class="form-control">
                                                    <option>Primary</option>
                                                    </select>
                                                </div>
                                                 <div class="col-lg-2">
                                                    <input class="form-control desabled" type="text" id="" name="" readonly>
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">WO No</label>
                                                 <div class="col-lg-6">
                                                    <input class="form-control desabled" type="text" id="" name="" readonly>
                                                </div>
                                                 <div class="col-lg-2">
                                                    <input class="form-control desabled" type="text" id="" name="" readonly>
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">BP Ref. No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Sample Type</label>
                                                <div class="col-lg-8">
                                                   <select class="form-select">
                                                       <option>Select</option>
                                                   </select>
                                                </div>
                                            </div>
                                        </div>  
                                        
                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">TR By</label>
                                                <div class="col-lg-8">
                                                    <select class="form-select">
                                                       <option>Select</option>
                                                   </select>
                                                </div>
                                            </div>
                                        </div>  

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Item Code</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Item Name</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>   

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">GRPO Qty</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>  

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Sample Qty</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Retain Qty</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>  

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">MFG By</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-5 col-form-label mt-6" for="val-skill">Total No of container</label>
                                                <div class="col-lg-7">
                                                    <input class="form-control" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div>  

                                          <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">From Container</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">To Container</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Batch No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Batch Qty</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">MFG Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                        <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Expiry Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Status</label>
                                                <div class="col-lg-4">
                                                    <input class="form-control desabled" type="text" id="" name="" readonly>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="form-check">
                                                      <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                                      <label class="form-check-label" for="flexCheckDefault">
                                                        Cancelled
                                                      </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">TR Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Branch</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div>  

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Challan No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="number" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Challan Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Gate Entry No</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Gate Entry Date</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="date" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Container Nos</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control desabled" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         <div class="col-xl-3 col-md-6">
                                            <div class="form-group row mb-2">
                                               <label class="col-lg-4 col-form-label mt-6" for="val-skill">Container</label>
                                                <div class="col-lg-8">
                                                    <input class="form-control" type="text" id="" name="">
                                                </div>
                                            </div>
                                        </div> 

                                         

                                      
                                     <!-- Toggle States Button -->
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Add</button>
                                                    <button type="button" class="btn btn-primary active" data-bs-toggle="button" autocomplete="off" aria-pressed="true">Cancel</button>
                                                     <button type="button" class="btn btn-primary " data-bs-toggle="button" autocomplete="off">Transfer To Undertest</button>
                                                     <input type="text" name="" class="desabled">
                                                     </div>
                                                  <div class="col-md-6 text-right">
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Print Undertest Label</button>
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Print Quarantine</button>
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="button" autocomplete="off">Print Sample Intimation</button>
                                                 </div>
                                            </div>
                                    </div>
                                 </form>

                                <!-- form end -->
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    </div>

    <!--end sample intimation model-->




        <script type="text/javascript">
(function ($) {

  $.fn.enableCellNavigation = function () {

    var arrow = {
      left: 37,
      up: 38,
      right: 39,
      down: 40
    };

    // select all on focus
    // works for input elements, and will put focus into
    // adjacent input or textarea. once in a textarea,
    // however, it will not attempt to break out because
    // that just seems too messy imho.
    this.find('input').keydown(function (e) {

      // shortcut for key other than arrow keys
      if ($.inArray(e.which, [arrow.left, arrow.up, arrow.right, arrow.down]) < 0) {
        return;
      }

      var input = e.target;
      var td = $(e.target).closest('td');
      var moveTo = null;

      switch (e.which) {

        case arrow.left:
          {
            if (input.selectionStart == 0) {
              moveTo = td.prev('td:has(input,textarea)');
            }
            break;
          }
        case arrow.right:
          {
            if (input.selectionEnd == input.value.length) {
              moveTo = td.next('td:has(input,textarea)');
            }
            break;
          }

        case arrow.up:
        case arrow.down:
          {

            var tr = td.closest('tr');
            var pos = td[0].cellIndex;

            var moveToRow = null;
            if (e.which == arrow.down) {
              moveToRow = tr.next('tr');
            } else if (e.which == arrow.up) {
              moveToRow = tr.prev('tr');
            }

            if (moveToRow.length) {
              moveTo = $(moveToRow[0].cells[pos]);
            }

            break;
          }

      }

      if (moveTo && moveTo.length) {

        e.preventDefault();

        moveTo.find('input,textarea').each(function (i, input) {
          input.focus();
          input.select();
        });

      }

    });

  };

})(jQuery);


// use the plugin
$(function () {
  $('#list').enableCellNavigation();
});


</script>
